
def concat(reps, scenes, batch, target_w=720, target_h=1280, fps=24):
    """Stream-copy concat when all clips share codec/res/fps/audio; else filter re-encode to target."""
    logp = os.path.join(batch, "logs", "ffmpeg.log")
    ok = [r for r in reps if r.get("local_file") and os.path.exists(r.get("local_file")) and os.path.getsize(r["local_file"]) > 0]
    if not ok:
        log("CONCAT: no valid clips", logp); return {"method": "none", "error": "no clips"}
    # strictly enforce scene order using scenes list
    by_scene = {s["scene_id"]: r for s in scenes for r in ok if r["scene_id"] == s["scene_id"]}
    ordered = [by_scene[s["scene_id"]] for s in scenes if s["scene_id"] in by_scene]
    if len(ordered) < len(ok):
        ordered = ok
    files = [r["local_file"] for r in ordered]
    out = os.path.join(batch, "final", "black_clothing_5scene_final.mp4")
    # probe each for compatibility
    def sig(f):
        p = ffprobe(f)
        v = next((s for s in p.get("streams",[]) if s.get("codec_type")=="video"), {})
        a = next((s for s in p.get("streams",[]) if s.get("codec_type")=="audio"), None)
        return (v.get("codec_name"), v.get("profile"), v.get("pix_fmt"), int(v.get("width",0)), int(v.get("height",0)),
                eval(v.get("avg_frame_rate","0/1")) if v.get("avg_frame_rate") else None,
                a.get("codec_name") if a else None, a.get("sample_rate") if a else None, a.get("channels") if a else None)
    sigs = [sig(f) for f in files]
    all_same = all(s == sigs[0] for s in sigs) and sigs[0][3:5] == (target_w, target_h)
    log(f"CONCAT compat={all_same} sigs={sigs}", logp)
    if all_same:
        lst = os.path.join(batch, "final", "concat_list.txt")
        with open(lst, "w") as f:
            for p in files:
                f.write(f"file '{p}'\n")
        cmd = [FFMPEG, "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", "-movflags", "+faststart", out]
    else:
        inp = []
        for p in files:
            inp += ["-i", p]
        n = len(files)
        filt = "".join(f"[{i}:v]scale={target_w}:{target_h}:flags=lanczos,setsar=1,fps={fps}[v{i}];" for i in range(n))
        # concat video + audio (audio may be absent -> use anullsrc-free approach: concat present streams)
        pairs = ""
        for i in range(n):
            pairs += f"[v{i}]"
            # attach audio only if present
        # Simpler: build concat with v only, and mux a silent audio track if none of the clips had audio
        has_audio = any(s[6] for s in sigs)
        fc = filt
        if has_audio:
            concat_map = "".join(f"[v{i}]" for i in range(n))
            # need v and a in order; build stream list
            stream_map = []
            for i in range(n):
                stream_map.append(f"[v{i}]")
            fc = filt + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[v]"
            cmd = [FFMPEG, "-y"] + inp + ["-filter_complex", fc, "-map", "[v]",
                "-c:v", "libx264", "-profile:v", "high", "-level", "4.0", "-pix_fmt", "yuv420p",
                "-r", str(fps), "-c:a", "copy", "-movflags", "+faststart", out]
        else:
            fc = filt + "".join(f"[v{i}]" for i in range(n)) + f"concat=n={n}:v=1:a=0[v]"
            cmd = [FFMPEG, "-y"] + inp + ["-filter_complex", fc, "-map", "[v]",
                "-c:v", "libx264", "-profile:v", "high", "-level", "4.0", "-pix_fmt", "yuv420p",
                "-r", str(fps), "-movflags", "+faststart", out]
    method = "stream-copy" if all_same else "re-encode"
    log(f"CONCAT method={method} files={len(files)}", logp)
    proc = subprocess.run(cmd, capture_output=True, text=True)
    tail = (proc.stderr or "")[-2500:]
    with open(os.path.join(batch, "logs", "ffmpeg_last.log"), "w") as f:
        f.write("RC=" + str(proc.returncode) + "\n" + tail)
    if proc.returncode != 0:
        log(f"CONCAT_FAIL: {tail[-1200:]}", logp)
        return {"method": method, "error": tail[-1500:], "rc": proc.returncode}
    return {"method": method, "output": out, "rc": proc.returncode,
            "compat": all_same, "sigs": [dict(zip(["codec","profile","pix_fmt","w","h","fps","audio","ar","ch"], s)) for s in sigs]}

def keyframe_times(path, fps=24):
    """Return list of I-frame pts times in seconds via ffmpeg showinfo."""
    p = subprocess.run([FFMPEG, "-hide_banner", "-i", path, "-vf",
        "select='eq(pict_type,I)',showinfo", "-f", "null", "-"], capture_output=True, text=True)
    import re
    return [float(m.group(1)) for m in re.finditer(r"pts_time:\s*([\d.]+)", p.stderr)]

def verify(out, expected_scenes, rep):
    res = {"exists": os.path.exists(out), "size": os.path.getsize(out) if os.path.exists(out) else 0}
    p = ffprobe(out)
    v = next((s for s in p.get("streams",[]) if s.get("codec_type")=="video"), {})
    a = next((s for s in p.get("streams",[]) if s.get("codec_type")=="audio"), None)
    fmt = p.get("format", {})
    res.update({
        "duration": float(fmt.get("duration",0)),
        "width": int(v.get("width",0)), "height": int(v.get("height",0)),
        "codec": v.get("codec_name"), "profile": v.get("profile"),
        "pix_fmt": v.get("pix_fmt"), "fps": eval(v.get("avg_frame_rate","0/1")) if v.get("avg_frame_rate") else None,
        "dar": fmt.get("display_aspect_ratio") or v.get("display_aspect_ratio"),
        "sar": v.get("sample_aspect_ratio"),
        "audio": ({"codec": a.get("codec_name"), "sample_rate": a.get("sample_rate"), "channels": a.get("channels")} if a else None),
        "container": fmt.get("format_name"),
    })
    # decode test
    dc = subprocess.run([FFMPEG, "-v", "error", "-i", out, "-f", "null", "-"], capture_output=True, text=True)
    res["decode_errors"] = (dc.stderr.strip() or "none"); res["decode_ok"] = dc.returncode == 0
    # scene boundaries via keyframes
    kts = keyframe_times(out, res.get("fps") or 24)
    res["keyframe_times"] = [round(k,3) for k in kts]
    # expected boundary per scene (~6s)
    res["scene_present"] = all(k < 25.5 for k in kts) and len(kts) >= expected_scenes
    res["pass"] = (res["decode_ok"] and res["exists"] and res["width"]==720 and res["height"]==1280
                   and res["codec"]=="h264" and res["pix_fmt"]=="yuv420p" and res["fps"]==24
                   and abs(res["duration"]-30) < 4 and res["scene_present"])
    return res

def write_report(batch, reps, scenes, concat_res, verify_res, key_source, manifest_extra):
    report = {
        "batch_id": manifest_extra.get("batch_id"),
        "started_at": manifest_extra.get("started_at"),
        "ended_at": datetime.now(timezone.utc).isoformat(),
        "openclaw_version": "2026.9.4",
        "node_version": "v24.21.0",
        "python_version": "3.12.3",
        "ffmpeg_version": "6.1.1 (system)",
        "agnes_endpoint": "https://apihub.agnes-ai.cn/v1",
        "key_source": key_source,
        "key_present": bool(API_KEY),
        "key_masked": mask(API_KEY),
        "model": manifest_extra.get("model"),
        "scenes": [
            {"scene_id": r["scene_id"], "title": next((s["title"] for s in scenes if s["scene_id"]==r["scene_id"]), r["scene_id"]),
             "task_id": r.get("task_id"), "status": r.get("status"), "model": r.get("model"),
             "video_url": r.get("video_url"), "local_file": r.get("local_file"),
             "file_size": r.get("file_size"), "error": r.get("error"),
             "poll_seconds": r.get("poll_seconds"), "fallback_used": r.get("fallback_used"),
             "ffprobe": r.get("ffprobe")}
            for r in reps
        ],
        "concat": concat_res,
        "verify": verify_res,
        "final_file": os.path.join(batch, "final", "black_clothing_5scene_final.mp4"),
    }
    with open(os.path.join(batch, "reports", "production-report.json"), "w") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    return report
